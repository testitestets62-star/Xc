# GitHub Browser

Android WebView browser project.

## GitHub Actions

The workflow intentionally does **not** use Gradle dependency caching and does not require a Gradle Wrapper. It installs Gradle 8.7 directly and builds the debug APK.

If an older workflow such as `build.yml` already exists in your repository, replace its contents with the `.github/workflows/build.yml` from this package, or delete the old workflow before uploading this package. GitHub runs every workflow file that remains in `.github/workflows/`.
